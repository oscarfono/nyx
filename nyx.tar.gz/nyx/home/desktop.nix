{ config, pkgs, lib, ... }:

# Nyx desktop, user side. Every colour comes from lib/melancholy.nix, so the
# bar, notifications, lock screen, terminal and Emacs cannot drift apart.

let
  t = import ../lib/melancholy.nix;
in
{
  # -------------------------------------------------------------------
  # Hyprland
  # -------------------------------------------------------------------
  wayland.windowManager.hyprland = {
    enable = true;
    settings = {
      "$mod" = "SUPER";
      "$terminal" = "ghostty";

      monitor = ",preferred,auto,1.25";   # 14in 1080p, 1.25 is comfortable

      general = {
        gaps_in = 4;
        gaps_out = 8;
        border_size = 2;
        "col.active_border" = t.hypr t.amber;
        "col.inactive_border" = t.hypr t.bgSubtle;
        layout = "dwindle";
      };

      decoration = {
        rounding = 6;
        blur.enabled = false;   # battery over spectacle
      };

      animations.enabled = true;

      input = {
        kb_layout = "us";
        follow_mouse = 1;
        touchpad.natural_scroll = true;
      };

      exec-once = [
        "waybar"
        "mako"
        "hypridle"
        "swayosd-server"
        "wl-paste --watch cliphist store"
      ];

      bind = [
        "$mod, Return, exec, $terminal"
        "$mod, E, exec, emacsclient -c -a ''"
        "$mod, B, exec, brave"
        "$mod SHIFT, B, exec, firefox"
        "$mod, P, exec, keepassxc"
        "$mod, Space, exec, fuzzel"
        "$mod, Q, killactive,"
        "$mod, F, fullscreen,"
        "$mod, V, togglefloating,"
        "$mod SHIFT, L, exec, hyprlock"
        "$mod, K, exec, ghostty -e 'less ~/.config/nyx/keybinds.txt'"
        "$mod ALT, Space, exec, nyx-menu-root"

        # Capture, the Omarchy pattern: region to clipboard, region to editor
        ", Print, exec, grim -g \"$(slurp)\" - | wl-copy"
        "SHIFT, Print, exec, grim -g \"$(slurp)\" - | satty -f -"
        "$mod SHIFT, R, exec, wf-recorder -g \"$(slurp)\" -f ~/Videos/rec-$(date +%s).mp4"
      ]
      ++ builtins.concatLists (builtins.genList
        (i: let ws = toString (i + 1); in [
          "$mod, ${ws}, workspace, ${ws}"
          "$mod SHIFT, ${ws}, movetoworkspace, ${ws}"
        ]) 9);

      bindel = [
        ",XF86AudioRaiseVolume, exec, swayosd-client --output-volume raise"
        ",XF86AudioLowerVolume, exec, swayosd-client --output-volume lower"
        ",XF86AudioMute, exec, swayosd-client --output-volume mute-toggle"
        ",XF86MonBrightnessUp, exec, swayosd-client --brightness raise"
        ",XF86MonBrightnessDown, exec, swayosd-client --brightness lower"
      ];
    };
  };

  # -------------------------------------------------------------------
  # Waybar
  # -------------------------------------------------------------------
  programs.waybar = {
    enable = true;
    settings.mainBar = {
      layer = "top";
      position = "top";
      height = 30;
      modules-left = [ "hyprland/workspaces" ];
      modules-center = [ "clock" ];
      modules-right = [ "pulseaudio" "backlight" "battery" "network" "tray" ];

      clock.format = "{:%a %d %b  %H:%M}";
      battery = {
        format = "{icon} {capacity}%";
        format-icons = [ "" "" "" "" "" ];
        states = { warning = 30; critical = 15; };
      };
      network.format-wifi = "  {essid}";
      pulseaudio.format = "  {volume}%";
      backlight.format = "  {percent}%";
    };

    style = ''
      * {
        font-family: "CommitMono Nerd Font Mono", monospace;
        font-size: 12px;
      }
      window#waybar {
        background: ${t.bg};
        color: ${t.fg};
        border-bottom: 2px solid ${t.bgSubtle};
      }
      #workspaces button          { color: ${t.fgMuted}; padding: 0 8px; }
      #workspaces button.active   { color: ${t.amber}; }
      #workspaces button.urgent   { color: ${t.red}; }
      #clock                      { color: ${t.cyan}; }
      #battery                    { color: ${t.green}; }
      #battery.warning            { color: ${t.amber}; }
      #battery.critical           { color: ${t.red}; }
      #network, #pulseaudio, #backlight { color: ${t.fg}; padding: 0 8px; }
    '';
  };

  # -------------------------------------------------------------------
  # Notifications
  # -------------------------------------------------------------------
  services.mako = {
    enable = true;
    settings = {
      background-color = t.bg;
      text-color = t.fg;
      border-color = t.amber;
      border-size = 2;
      border-radius = 6;
      default-timeout = 5000;
      font = "Raleway 11";
    };
  };

  # -------------------------------------------------------------------
  # Launcher
  # -------------------------------------------------------------------
  programs.fuzzel = {
    enable = true;
    settings = {
      main.font = "CommitMono Nerd Font Mono:size=12";
      colors = {
        background = "${lib.removePrefix "#" t.bg}ee";
        text = "${lib.removePrefix "#" t.fg}ff";
        match = "${lib.removePrefix "#" t.amber}ff";
        selection = "${lib.removePrefix "#" t.bgSubtle}ff";
        selection-text = "${lib.removePrefix "#" t.fgString}ff";
        border = "${lib.removePrefix "#" t.amber}ff";
      };
    };
  };

  # -------------------------------------------------------------------
  # Lock and idle
  # -------------------------------------------------------------------
  programs.hyprlock = {
    enable = true;
    settings = {
      background = [{ color = t.bg; }];
      input-field = [{
        size = "300, 50";
        outline_thickness = 2;
        outer_color = t.amber;
        inner_color = t.bgSubtle;
        font_color = t.fg;
        placeholder_text = "";
      }];
    };
  };

  services.hypridle = {
    enable = true;
    settings = {
      general = {
        lock_cmd = "pidof hyprlock || hyprlock";
        before_sleep_cmd = "loginctl lock-session";
        after_sleep_cmd = "hyprctl dispatch dpms on";
      };
      listener = [
        { timeout = 240; on-timeout = "brightnessctl -s set 10"; on-resume = "brightnessctl -r"; }
        { timeout = 300; on-timeout = "loginctl lock-session"; }
        { timeout = 360; on-timeout = "hyprctl dispatch dpms off"; on-resume = "hyprctl dispatch dpms on"; }
        { timeout = 900; on-timeout = "systemctl suspend"; }
      ];
    };
  };

  # -------------------------------------------------------------------
  # Terminal
  # -------------------------------------------------------------------
  programs.ghostty = {
    enable = true;
    settings = {
      font-family = "CommitMono Nerd Font Mono";
      font-size = 11;
      background = t.bg;
      foreground = t.fg;
      cursor-color = t.cyan;
      selection-background = t.bgSubtle;
      selection-foreground = t.fgString;
      background-opacity = 0.96;
      window-padding-x = 10;
      window-padding-y = 10;
      palette = lib.mapAttrsToList
        (n: v: "${lib.removePrefix "color" n}=${v}") t.ansi;
    };
  };

  # A keybind cheatsheet, generated from the binds above rather than
  # maintained by hand. Super+K opens it.
  xdg.configFile."nyx/keybinds.txt".text =
    lib.concatStringsSep "\n"
      config.wayland.windowManager.hyprland.settings.bind;
}
